package com.example.listview;

import java.io.Serializable;

public class Article implements Serializable{
    private int code;
    private String Libel;
    private int pv;


    public Article(int code, String libel, int pv) {
        this.code = code;
        Libel = libel;
        this.pv = pv;
    }

    public int getCode() {
        return code;
    }

    public String getLibel() {
        return Libel;
    }

    public int getPv() {
        return pv;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setLibel(String libel) {
        Libel = libel;
    }

    public void setPv(int pv) {
        this.pv = pv;
    }

    @Override
    public String toString() {
        return "Article{" +
                "code=" + code +
                ", Libel='" + Libel + '\'' +
                ", pv=" + pv +
                '}';
    }
}
